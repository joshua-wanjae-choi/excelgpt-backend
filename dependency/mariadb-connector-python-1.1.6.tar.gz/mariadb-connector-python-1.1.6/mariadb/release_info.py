__author__ = 'Georg Richter'
__version__ = '1.1.6'
__version_info__ = (1, 1, 6)
